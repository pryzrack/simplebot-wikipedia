from setuptools import setup


setup(
    name='simplebot-wikipedia',
    version='1.0',
    scripts=['main.py'],
)